App({
  data: () => ({}),
  onLoad() {},
  onReady() {},
  onUnload() {},
  onShow() {},
  onHide() {}
});
