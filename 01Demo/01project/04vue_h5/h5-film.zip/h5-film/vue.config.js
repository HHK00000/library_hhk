// vue.config.js
module.exports = {
  productionSourceMap: false,
    css: {
      requireModuleExtension: true,
      loaderOptions: {
        css: {
            modules: {
                modules: true
            }
        } 
      }
    },
    devServer: {
      open: true,
      host: "localhost",
      disableHostCheck: true,
      port: 8080,
      proxy: {
        "/api": {
          target: "http://10.16.61.54:10004/",
          changeOrigin: true,
          pathRewrite: {
            "^/api": "/"
          },
        },
      },
    },
    lintOnSave: false
  }