var fs = require('fs')
var path = require('path')
var qcdn = require('@q/qcdn')

// CSS
fs.readdir(path.resolve('./dist/css'), function (err, files) {
    if (err) {
      return console.log('目录不存在')
    }
    filePath = files.map((name)=>{
        return `./dist/css/${name}`
    })

    qcdn.upload(filePath, {
        image: {
            https: true,
            domains: ['s0.qhimg.com']
        },
        static: {
            https: true,
            domains: ['s0.qhimg.com']
        }
    }).then(res=>{
        console.log('-------- CSS QCDN RES ---------')
        console.log(res)
        var readMe = fs.readFileSync('./dist/index.html', 'utf8');
        Object.keys(res).forEach(k=>{
            readMe = readMe.replaceAll(k.replace('./dist', ''), res[k])
        })
        fs.writeFileSync('./dist/index.html', readMe)
        console.log('Done!')
    })
})

// JS
fs.readdir(path.resolve('./dist/js'), function (err, files) {
    if (err) {
      return console.log('目录不存在')
    }
    filePath = files.map((name)=>{
        return `./dist/js/${name}`
    })

    qcdn.upload(filePath, {
        image: {
            https: true,
            domains: ['p1.ssl.qhimg.com', 'p2.ssl.qhimg.com']
        },
        static: {
            https: true,
            domains: ['s0.qhimg.com']
        }
    }).then(res=>{
        console.log('-------- JSS QCDN RES ---------')
        console.log(res)
        var readMe = fs.readFileSync('./dist/index.html', 'utf8');
        Object.keys(res).forEach(k=>{
            readMe = readMe.replaceAll(k.replace('./dist', ''), res[k])
        })
        fs.writeFileSync('./dist/index.html', readMe)
        console.log('Done!')
    })
})