require('./qhgame-adapter.js');
require('./platform.js');
require('./manifest.js');
require('./egret.wxgame.js');

egret.runEgret({
    //以下为自动修改，请勿修改
    //The following is automatically modified, please do not modify
    //----auto option start----
    entryClassName: "Main",
    orientation: "auto",
    frameRate: 30,
    scaleMode: "showAll",
    contentWidth: 960,
    contentHeight: 540,
    showFPS: false,
    fpsStyles: "x:0,y:0,size:12,textColor:0xffffff,bgAlpha:0.9",
    showLog: false,
    maxTouches: 2,
    //----auto option end----
    renderMode: 'webgl',
    audioType: 0,
    calculateCanvasScaleFactor: function (context) {
        // return 1;
        var backingStore = context.backingStorePixelRatio ||
            context.webkitBackingStorePixelRatio ||
            context.mozBackingStorePixelRatio ||
            context.msBackingStorePixelRatio ||
            context.oBackingStorePixelRatio ||
            context.backingStorePixelRatio || 1;


        console.log(backingStore);
        console.log(window.devicePixelRatio)

        return (window.devicePixelRatio || 1) / backingStore;
    }
});