var CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = (env) => {
    const mode = env.prod ? 'production' : "development";
    return {
        entry: "./game.js",
        output: {
            filename: "game.js"
        },
        mode,
        plugins: [
            new CopyWebpackPlugin([{ from: './game.json', to: 'game.json' }])
        ]
    }

}