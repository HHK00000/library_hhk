var egret = window.egret;var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var CollisionSystem = (function () {
    function CollisionSystem() {
        this.others = [];
    }
    CollisionSystem.prototype.addSubmarine = function (submarine) {
        this.submarine = submarine;
    };
    CollisionSystem.prototype.addPipe = function (pipe) {
        this.others.push(pipe);
    };
    CollisionSystem.prototype.addOther = function (other) {
        this.others.push(other);
    };
    CollisionSystem.prototype.clearOthers = function () {
        this.others = [];
    };
    CollisionSystem.prototype.runSystem = function () {
        var result = false;
        if (this.submarine) {
            // 圆心坐标
            var r = this.submarine.width / 2;
            var x = this.submarine.localToGlobal().x + r;
            var y = this.submarine.localToGlobal().y + r;
            result = this.hitTest(x, y, r);
        }
        return result;
    };
    CollisionSystem.prototype.hitTest = function (x, y, r) {
        for (var _i = 0, _a = this.others; _i < _a.length; _i++) {
            var other = _a[_i];
            var left = other.localToGlobal().x;
            var right = left + other.width;
            var top_1 = other.localToGlobal().y;
            var bottom = top_1 + other.height;
            var closeX = 0;
            var closeY = 0;
            if (x < left) {
                closeX = left;
            }
            else if (x > right) {
                closeX = right;
            }
            else {
                closeX = x;
            }
            if (y < top_1) {
                closeY = top_1;
            }
            else if (y > bottom) {
                closeY = bottom;
            }
            else {
                closeY = y;
            }
            var distance = Math.sqrt(Math.pow(closeX - x, 2) + Math.pow(closeY - y, 2));
            if (distance < r) {
                return true;
            }
        }
        return false;
    };
    CollisionSystem.prototype.clear = function () {
        this.others = [];
    };
    return CollisionSystem;
}());
__reflect(CollisionSystem.prototype, "CollisionSystem");
var GameOver = (function (_super) {
    __extends(GameOver, _super);
    function GameOver(config) {
        if (config === void 0) { config = {
            x: 0,
            y: 0,
            center: false,
            stageW: 960,
            stageH: 540
        }; }
        var _this = _super.call(this) || this;
        _this.gameOverText = createBitmapByName('game_over');
        _this.restartButton = createBitmapByName('restart_button');
        var x = config.x;
        var y = config.y;
        if (config.center) {
            x = (config.stageW - _this.gameOverText.width) / 2;
            y = (config.stageH - _this.gameOverText.height - _this.restartButton.height) / 2;
        }
        _this.x = x;
        _this.y = y;
        _this.addChild(_this.gameOverText);
        _this.addChild(_this.restartButton);
        _this.restartButton.y = _this.gameOverText.height;
        _this.restartButton.x = (_this.gameOverText.width - _this.restartButton.width) / 2;
        return _this;
    }
    return GameOver;
}(egret.DisplayObjectContainer));
__reflect(GameOver.prototype, "GameOver");
//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////
var LoadingUI = (function (_super) {
    __extends(LoadingUI, _super);
    function LoadingUI() {
        var _this = _super.call(this) || this;
        _this.createView();
        return _this;
    }
    LoadingUI.prototype.createView = function () {
        this.textField = new egret.TextField();
        this.addChild(this.textField);
        this.textField.y = 300;
        this.textField.width = 480;
        this.textField.height = 100;
        this.textField.textAlign = "center";
    };
    LoadingUI.prototype.onProgress = function (current, total) {
        this.textField.text = "Loading..." + current + "/" + total;
    };
    return LoadingUI;
}(egret.Sprite));
__reflect(LoadingUI.prototype, "LoadingUI", ["RES.PromiseTaskReporter"]);
//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////
var Main = (function (_super) {
    __extends(Main, _super);
    function Main() {
        var _this = _super.call(this) || this;
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.onAddToStage, _this);
        return _this;
    }
    Main.prototype.onAddToStage = function (event) {
        egret.lifecycle.addLifecycleListener(function (context) {
            // custom lifecycle plugin
            context.onUpdate = function () {
            };
        });
        egret.lifecycle.onPause = function () {
            egret.ticker.pause();
        };
        egret.lifecycle.onResume = function () {
            egret.ticker.resume();
        };
        this.runGame().catch(function (e) {
            console.log(e);
        });
    };
    Main.prototype.runGame = function () {
        return __awaiter(this, void 0, void 0, function () {
            var userInfo;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadResource()];
                    case 1:
                        _a.sent();
                        this.createGameScene();
                        return [4 /*yield*/, platform.login()];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, platform.getUserInfo()];
                    case 3:
                        userInfo = _a.sent();
                        console.log(userInfo);
                        return [2 /*return*/];
                }
            });
        });
    };
    Main.prototype.loadResource = function () {
        return __awaiter(this, void 0, void 0, function () {
            var loadingView, e_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 3, , 4]);
                        loadingView = new LoadingUI();
                        this.stage.addChild(loadingView);
                        return [4 /*yield*/, RES.loadConfig("resource/default.res.json", "resource/")];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, RES.loadGroup("preload", 0, loadingView)];
                    case 2:
                        _a.sent();
                        this.stage.removeChild(loadingView);
                        return [3 /*break*/, 4];
                    case 3:
                        e_1 = _a.sent();
                        console.error(e_1);
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * 创建游戏场景
     * Create a game scene
     */
    Main.prototype.createGameScene = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var config, stageW, stageH, backgroud, submarine, pipe, bottomMask, gameOver, scoreConfig, scoreText, gameOverHandler, collisionHandler;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        // 创建碰撞系统
                        this.collisionSystem = new CollisionSystem();
                        return [4 /*yield*/, RES.getResAsync('default_config')];
                    case 1:
                        config = _a.sent();
                        stageW = this.stage.stageWidth;
                        stageH = this.stage.stageHeight;
                        backgroud = createBitmapByName("bg_repeat");
                        backgroud.width = stageW;
                        backgroud.height = stageH;
                        this.addChild(backgroud);
                        submarine = new Submarine(config.submarine);
                        this.submarine = submarine;
                        this.addChild(submarine);
                        pipe = new Pipe(config.pipe);
                        this.pipe = pipe;
                        pipe.collisionSystem = this.collisionSystem;
                        pipe.submarine = submarine;
                        this.addChild(pipe);
                        bottomMask = createBitmapByName("mask");
                        bottomMask.width = stageW;
                        bottomMask.y = stageH - bottomMask.height;
                        this.bottomMask = bottomMask;
                        this.addChild(bottomMask);
                        gameOver = new GameOver(config.gameOver);
                        gameOver.visible = false;
                        this.addChild(gameOver);
                        scoreConfig = config.scoreText;
                        scoreText = new egret.TextField();
                        scoreText.x = scoreConfig.x;
                        scoreText.y = scoreConfig.y;
                        scoreText.size = scoreConfig.size;
                        scoreText.text = "";
                        this.addChild(scoreText);
                        this.collisionSystem.addSubmarine(submarine);
                        this.collisionSystem.addOther(bottomMask);
                        gameOverHandler = function (e) {
                            e.stopImmediatePropagation();
                            gameOver.visible = false;
                            _this.restart();
                        };
                        gameOver.restartButton.addEventListener(egret.TouchEvent.TOUCH_BEGIN, gameOverHandler, this);
                        collisionHandler = function () { return __awaiter(_this, void 0, void 0, function () {
                            var result;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        scoreText.text = "\u5F97\u5206 : " + submarine.score;
                                        result = this.collisionSystem.runSystem();
                                        if (!result) return [3 /*break*/, 2];
                                        this.stop();
                                        gameOver.visible = true;
                                        gameOver.restartButton.visible = false;
                                        return [4 /*yield*/, new Promise(function (resolve) { return setTimeout(resolve, 1000); })];
                                    case 1:
                                        _a.sent();
                                        gameOver.restartButton.visible = true;
                                        gameOver.restartButton.touchEnabled = true;
                                        _a.label = 2;
                                    case 2: return [2 /*return*/];
                                }
                            });
                        }); };
                        this.stage.addEventListener(egret.Event.ENTER_FRAME, collisionHandler, this);
                        this.stage.addEventListener(egret.TouchEvent.TOUCH_BEGIN, function () {
                            submarine.jump();
                            pipe.setSpeedX(pipe.speed);
                        }, this);
                        return [2 /*return*/];
                }
            });
        });
    };
    Main.prototype.stop = function () {
        this.collisionSystem.clearOthers();
        this.submarine.clear();
        this.pipe.clear();
    };
    Main.prototype.restart = function () {
        this.submarine.restart();
        this.pipe.restart();
        this.collisionSystem.addOther(this.bottomMask);
    };
    return Main;
}(egret.DisplayObjectContainer));
__reflect(Main.prototype, "Main");
var Pipe = (function (_super) {
    __extends(Pipe, _super);
    function Pipe(config) {
        if (config === void 0) { config = {
            startX: 540,
            heightSpace: 128,
            widthSpace: 240,
            pipeWidth: 69,
            stageW: 960,
            speed: 0
        }; }
        var _this = _super.call(this) || this;
        _this.startX = 0;
        _this.heightSpace = 0;
        _this.widthSpace = 0;
        _this.stageW = 0;
        _this.pipeWidth = 69;
        _this.pause = false;
        _this.pipes = [];
        _this.speedX = 0;
        _this.speed = 0;
        _this.config = {};
        _this.init(config);
        _this.addEventListener(egret.Event.ENTER_FRAME, function () {
            if (_this.startX <= _this.stageW) {
                _this.createPipe(_this.startX);
                _this.startX += _this.widthSpace + _this.pipeWidth;
            }
            if (_this.pipes.length > 0 && _this.submarine) {
                if (_this.pipes[0].x + _this.pipeWidth < _this.submarine.x) {
                    _this.pipes.shift();
                    _this.submarine.score++;
                }
            }
            _this.startX -= _this.speedX;
        }, _this);
        return _this;
    }
    Pipe.prototype.setSpeedX = function (speedX) {
        if (!this.pause) {
            this.speedX = speedX;
        }
    };
    Pipe.prototype.init = function (config) {
        if (config === void 0) { config = {
            startX: 540,
            heightSpace: 128,
            widthSpace: 240,
            pipeWidth: 69,
            stageW: 960,
            speed: 0
        }; }
        this.config = config;
        this.startX = config.startX;
        this.heightSpace = config.heightSpace;
        this.widthSpace = config.widthSpace;
        this.pipeWidth = config.pipeWidth;
        this.stageW = config.stageW;
        this.speed = config.speed;
        this.pipes = [];
    };
    Pipe.prototype.createPipe = function (x) {
        var _this = this;
        var container = new egret.DisplayObjectContainer();
        var top = createBitmapByName("pipe_top");
        var bottom = createBitmapByName("pipe_bottom");
        var dy = Math.ceil(Math.random() * this.heightSpace);
        top.y -= dy;
        bottom.y = top.height + this.heightSpace - dy;
        container.addChild(top);
        container.addChild(bottom);
        container.x = x;
        this.addChild(container);
        var handler = function () {
            container.x -= _this.speedX;
            if (container.x + _this.pipeWidth < 0) {
                container.removeEventListener(egret.Event.ENTER_FRAME, handler, _this);
                if (container.parent == _this) {
                    _this.removeChild(container);
                }
            }
        };
        if (this.collisionSystem) {
            this.collisionSystem.addPipe(top);
            this.collisionSystem.addPipe(bottom);
        }
        this.pipes.push(container);
        container.addEventListener(egret.Event.ENTER_FRAME, handler, this);
    };
    Pipe.prototype.clear = function () {
        this.pause = true;
        this.speedX = 0;
    };
    Pipe.prototype.restart = function () {
        this.pause = false;
        this.removeChildren();
        this.init(this.config);
    };
    return Pipe;
}(egret.DisplayObjectContainer));
__reflect(Pipe.prototype, "Pipe");
var DebugPlatform = (function () {
    function DebugPlatform() {
    }
    DebugPlatform.prototype.getUserInfo = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, { nickName: "username" }];
            });
        });
    };
    DebugPlatform.prototype.login = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/];
            });
        });
    };
    return DebugPlatform;
}());
__reflect(DebugPlatform.prototype, "DebugPlatform", ["Platform"]);
if (!window.platform) {
    window.platform = new DebugPlatform();
}
var Submarine = (function (_super) {
    __extends(Submarine, _super);
    function Submarine(config) {
        if (config === void 0) { config = {
            x: 270,
            y: 270,
            width: 60,
            height: 60,
            upSpeedY: 12,
            acceleration: 1.5,
            maxRotation: 15
        }; }
        var _this = _super.call(this) || this;
        _this.isStart = true;
        _this.isUp = false;
        _this.upSpeedY = 0;
        _this.currentSpeedY = 0;
        _this.acceleration = 0;
        _this.pause = false;
        _this.maxRotation = 0;
        _this.config = {};
        _this.score = 0;
        var bitmap = createBitmapByName("submarine");
        _this.submarine = new egret.DisplayObjectContainer();
        _this.submarine.addChild(bitmap);
        _this.submarineBitmap = bitmap;
        _this.submarineMask = createBitmapByName("submarine_mask");
        _this.addChild(_this.submarine);
        _this.addChild(_this.submarineMask);
        _this.init(config);
        _this.addEventListener(egret.Event.ENTER_FRAME, _this.update, _this);
        return _this;
    }
    Submarine.prototype.init = function (config) {
        if (config === void 0) { config = {
            x: 270,
            y: 270,
            width: 60,
            height: 60,
            upSpeedY: 12,
            acceleration: 1.5,
            maxRotation: 15
        }; }
        this.config = config;
        this.x = config.x;
        this.y = config.y;
        this.width = config.width;
        this.height = config.height;
        this.submarineMask.width = config.width;
        this.submarineMask.height = config.height;
        this.submarineBitmap.width = config.width;
        this.submarineBitmap.height = config.height;
        var dw = config.width / 2;
        var dh = config.height / 2;
        this.submarine.x = dw;
        this.submarine.y = dh;
        this.submarineBitmap.x = -dw;
        this.submarineBitmap.y = -dh;
        this.upSpeedY = config.upSpeedY;
        this.acceleration = config.acceleration;
        this.maxRotation = config.maxRotation;
        this.isStart = true;
        this.score = 0;
        this.submarine.rotation = 0;
    };
    Submarine.prototype.update = function (e) {
        if (!this.isStart) {
            if (this.isUp) {
                this.submarine.rotation = -this.maxRotation;
            }
            else {
                this.submarine.rotation = 0;
            }
            this.y += this.currentSpeedY;
            this.currentSpeedY = this.calculateSpeed();
        }
    };
    Submarine.prototype.calculateSpeed = function () {
        if (this.currentSpeedY > 0) {
            this.isUp = false;
        }
        if (this.currentSpeedY == this.upSpeedY) {
            return this.currentSpeedY;
        }
        return this.currentSpeedY + this.acceleration;
    };
    Submarine.prototype.jump = function () {
        if (!this.pause) {
            if (this.isStart) {
                this.isStart = false;
            }
            this.currentSpeedY = -this.upSpeedY;
            this.isUp = true;
        }
    };
    Submarine.prototype.clear = function () {
        this.currentSpeedY = 0;
        this.acceleration = 0;
        this.upSpeedY = 0;
        this.pause = true;
    };
    Submarine.prototype.restart = function () {
        this.pause = false;
        this.init(this.config);
    };
    return Submarine;
}(egret.DisplayObjectContainer));
__reflect(Submarine.prototype, "Submarine");
/**
 * 根据name关键字创建一个Bitmap对象。name属性请参考resources/resource.json配置文件的内容。
 * Create a Bitmap object according to name keyword.As for the property of name please refer to the configuration file of resources/resource.json.
 */
function createBitmapByName(name) {
    var result = new egret.Bitmap();
    var texture = RES.getRes(name);
    result.texture = texture;
    return result;
}

;window.Main = Main;